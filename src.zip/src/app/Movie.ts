export class Movie {
  movieName: string;
  rating: number;
  genre: string;
  constructor(movieName:string,rating:number,genre:string)
  {
this.movieName=movieName;
this.rating=rating;
this.genre=genre;

  }
}
